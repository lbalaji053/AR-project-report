using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using Vuforia;

public class click : MonoBehaviour
{
    InputField wet;
    InputField dry;
    public VirtualButtonBehaviour Vb_on;
 
    void Start()
    {
        wet = GameObject.Find("InputFieldwet").GetComponent<InputField>();
        
        dry = GameObject.Find("InputFielddry").GetComponent<InputField>();

        Vb_on.RegisterOnButtonPressed(OnButtonPressed_on);
        // GameObject.Find("GetButton").GetComponent<Button>().onClick.AddListener(GetData);
     
       GetData_tem();
        GetData_hum();
         wet.text = "16";//field.text.Substring(2,2);

        dry.text = "18";

    }

    public void OnButtonPressed_on(VirtualButtonBehaviour Vb_on)
    {
        GetData_tem();
        GetData_hum();
        
        
        Debug.Log("Click");
    }
 
    void GetData_tem() => StartCoroutine(GetData_Coroutine1());
    void GetData_hum() => StartCoroutine(GetData_Coroutine());
 
    IEnumerator GetData_Coroutine1()
    {
        Debug.Log("Getting Data");
        wet.text = "Loading...";
        string uri = "https://ar.bps-ec-iiot.in/data_res.php?val=0";
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {

            yield return request.SendWebRequest();
           
           
            {

                //InputFieldFlow.text = request.downloadHandler.text;
              wet.text =  request.downloadHandler.text;;//field.text.Substring(2,2);
            }
        }
        //GetData_hum();
    }
    IEnumerator GetData_Coroutine()
    {
        Debug.Log("Getting Data");
        dry.text = "Loading...";
        string uri = "https://ar.bps-ec-iiot.in/data_res.php?val=1";
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {
            yield return request.SendWebRequest();
          

                //InputFieldTotal.text = request.downloadHandler.text;
               dry.text =  request.downloadHandler.text;//Hum.text.Substring(2,2);
            
        }
    }
}