using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using Vuforia;

public class click : MonoBehaviour
{
    InputField flow;
    InputField vol;
    public VirtualButtonBehaviour Vb_on;
 
    void Start()
    {
        flow = GameObject.Find("flow").GetComponent<InputField>();
        
        vol = GameObject.Find("vol").GetComponent<InputField>();

        Vb_on.RegisterOnButtonPressed(OnButtonPressed_on);
        // GameObject.Find("GetButton").GetComponent<Button>().onClick.AddListener(GetData);
     
       GetData_tem();
        GetData_hum();
         flow.text = "16";//field.text.Substring(2,2);

        vol.text = "18";

    }

    public void OnButtonPressed_on(VirtualButtonBehaviour Vb_on)
    {
        GetData_tem();
        GetData_hum();
        
        
        Debug.Log("Click");
    }
 
    void GetData_tem() => StartCoroutine(GetData_Coroutine1());
    void GetData_hum() => StartCoroutine(GetData_Coroutine());
 
    IEnumerator GetData_Coroutine1()
    {
        Debug.Log("Getting Data");
        flow.text = "Loading...";
        string uri = "https://ar.drr-ec-106.in/data_res.php?val=0";
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {

            yield return request.SendWebRequest();
           
           
            {

                //InputFieldFlow.text = request.downloadHandler.text;
              flow.text =  request.downloadHandler.text;;//field.text.Substring(2,2);
            }
        }
        //GetData_hum();
    }
    IEnumerator GetData_Coroutine()
    {
        Debug.Log("Getting Data");
        vol.text = "Loading...";
        string uri = "https://ar.drr-ec-106.in/data_res.php?val=1";
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {
            yield return request.SendWebRequest();
          

                //InputFieldTotal.text = request.downloadHandler.text;
               vol.text =  request.downloadHandler.text;//Hum.text.Substring(2,2);
            
        }
    }
}