using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using Vuforia;

public class click : MonoBehaviour
{
    InputField temp;
    InputField hum;
    public VirtualButtonBehaviour Vb_on;
    static int i=0;
 
    void Start()
    {
        temp = GameObject.Find("temp").GetComponent<InputField>();
        
        hum = GameObject.Find("hum").GetComponent<InputField>();

        Vb_on.RegisterOnButtonPressed(OnButtonPressed_on);
        // GameObject.Find("GetButton").GetComponent<Button>().onClick.AddListener(GetData);
     
       GetData_tem();
        GetData_hum();
        

    }

    public void OnButtonPressed_on(VirtualButtonBehaviour Vb_on)
    {
        
       SetData_led();
    }
 
    void GetData_tem() => StartCoroutine(GetData_Coroutine1());
    void GetData_hum() => StartCoroutine(GetData_Coroutine());
    void SetData_led() => StartCoroutine(GetData_Coroutine2());
 
    IEnumerator GetData_Coroutine1()
    {
        Debug.Log("Getting Data");
        temp.text = "Loading...";
        string uri = "http://io.hexitronics.in/out.php";
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {
              
            
            yield return request.SendWebRequest();
           
            if(request.result == UnityWebRequest.Result.Success)
            {

                temp.text = request.downloadHandler.text;
              //  temp.text = "16";//field.text.Substring(2,2);
            }
            else
            {
                temp.text = "Er";
            }
        }
        //GetData_hum();
    }
    IEnumerator GetData_Coroutine()
    {
        Debug.Log("Getting Data");
       // hum.text = "Loading...";
        string uri = "http://io.hexitronics.in/out.php";
        
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {
            yield return request.SendWebRequest();
          if(request.result == UnityWebRequest.Result.Success)
            {

                hum.text = request.downloadHandler.text;
              //  temp.text = "16";//field.text.Substring(2,2);
            }
         else
            {
                hum.text = "Er";
            }
               
            
        }
    }

    IEnumerator GetData_Coroutine2()
    {
        string uri = "";
       if(i==0)
        {uri = "http://io.hexitronics.in/led.php?val0=1";
        i=1;}
        else
       if(i==1)
        {uri += "http://io.hexitronics.in/led.php?val0=0";
        i=0;}
        
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {
              
            
            yield return request.SendWebRequest();
           
          
        }
        //GetData_hum();
    }
}