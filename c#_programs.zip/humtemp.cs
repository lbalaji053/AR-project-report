using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using Vuforia;

public class click : MonoBehaviour
{
    InputField temp;
    InputField hum;
    public VirtualButtonBehaviour Vb_on;
 
    void Start()
    {
        temp = GameObject.Find("temp").GetComponent<InputField>();
        
        hum = GameObject.Find("hum").GetComponent<InputField>();

        Vb_on.RegisterOnButtonPressed(OnButtonPressed_on);
        // GameObject.Find("GetButton").GetComponent<Button>().onClick.AddListener(GetData);
     
      
        

    }

    public void OnButtonPressed_on(VirtualButtonBehaviour Vb_on)
    {
        GetData_tem();
        GetData_hum();
        
        Debug.Log("Click");
    }
 
    void GetData_tem() => StartCoroutine(GetData_Coroutine1());
    void GetData_hum() => StartCoroutine(GetData_Coroutine());
 
    IEnumerator GetData_Coroutine1()
    {
        Debug.Log("Getting Data");
        temp.text = "Loading...";
        string uri = "http://io.hexitronics.in/out.php";
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {

            yield return request.SendWebRequest();
           
           
            {

                temp.text = request.downloadHandler.text;
              //  temp.text = "16";//field.text.Substring(2,2);
            }
        }
        //GetData_hum();
    }
    IEnumerator GetData_Coroutine()
    {
        Debug.Log("Getting Data");
       // hum.text = "Loading...";
        string uri = "http://io.hexitronics.in/out.php";
        using(UnityWebRequest request = UnityWebRequest.Get(uri))
        {
            yield return request.SendWebRequest();
          

                hum.text = request.downloadHandler.text;
               // hum.text = "18";//Hum.text.Substring(2,2);
            
        }
    }
}